class Animal {
}

class Dog extends Animal {
}

class Cat extends Animal {
}

public class InstanceofDemo {
    public static void main(String[] args) {
        Animal a = new Dog();
        if (a instanceof Dog) {
            System.out.println("a is a Dog");
        }
        if (a instanceof Cat) {
            System.out.println("a is a Cat");
        }
        if (a instanceof Animal) {
            System.out.println("a is an Animal");
        }
        if (a instanceof Object) {
            System.out.println("a is an Object");
        }
    }
}