class Calculator {
    int multiply(int a, int b) {
        return a * b;
    }
    double multiply(double a, double b) {
        return a * b;
    }
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        System.out.println("Multiply int: " + calc.multiply(5, 10));
        System.out.println("Multiply double: " + calc.multiply(2.5, 4.5));
    }
}