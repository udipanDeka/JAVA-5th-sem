class Person {
    Person() {
        System.out.println("Person constructor called");
    }
}

class Employee extends Person {
    Employee() {
        super();
        System.out.println("Employee constructor called");
    }
}

class Manager extends Employee {
    Manager() {
        super();
        System.out.println("Manager constructor called");
    }
    public static void main(String[] args) {
        System.out.println("Creating a Manager object:");
        Manager m = new Manager();
    }
}