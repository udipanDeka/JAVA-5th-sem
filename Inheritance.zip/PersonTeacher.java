class Person {
    String name;
    int age;
    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    void displayPerson() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

class Teacher extends Person {
    String subject;
    double salary;
    Teacher(String name, int age, String subject, double salary) {
        super(name, age);
        this.subject = subject;
        this.salary = salary;
    }
    void displayTeacher() {
        displayPerson();
        System.out.println("Subject: " + subject);
        System.out.println("Salary: " + salary);
    }
    public static void main(String[] args) {
        Teacher t = new Teacher("Rahul Sharma", 35, "Mathematics", 45000);
        System.out.println("--- Teacher Details ---");
        t.displayTeacher();
    }
}