import java.util.Scanner;

class Rectangle {
    double length;
    double breadth;

    // Method to input values
    void inputValues() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter length: ");
        length = sc.nextDouble();
        System.out.print("Enter breadth: ");
        breadth = sc.nextDouble();
    }

    // Method to calculate area
    double area() {
        return length * breadth;
    }

    // Method to calculate perimeter
    double perimeter() {
        return 2 * (length + breadth);
    }

    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        r.inputValues();
        System.out.println("Area = " + r.area());
        System.out.println("Perimeter = " + r.perimeter());
    }
}