import java.util.Scanner;

class TemperatureConverter {

    // Celsius to Fahrenheit
    double celsiusToFahrenheit(double c) {
        return (c * 9 / 5) + 32;
    }

    // Fahrenheit to Celsius
    double fahrenheitToCelsius(double f) {
        return (f - 32) * 5 / 9;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TemperatureConverter tc = new TemperatureConverter();

        System.out.println("Choose conversion:");
        System.out.println("1. Celsius to Fahrenheit");
        System.out.println("2. Fahrenheit to Celsius");

        int choice = sc.nextInt();

        if (choice == 1) {
            System.out.print("Enter temperature in Celsius: ");
            double c = sc.nextDouble();
            System.out.println("Fahrenheit = " + tc.celsiusToFahrenheit(c));
        } else if (choice == 2) {
            System.out.print("Enter temperature in Fahrenheit: ");
            double f = sc.nextDouble();
            System.out.println("Celsius = " + tc.fahrenheitToCelsius(f));
        } else {
            System.out.println("Invalid choice!");
        }
    }
}